package toyproject.instragram.common.auth;

public class SessionConst {

    public static final String SIGN_IN_MEMBER = "signInMember";
}
